import uniswap from "./uniswap.png";
import search from "./Search.png";
import ether from "./ether.png";
import arrow from "./arrow.png";
import arrowup from "./arrow up.png";
import close from "./cross.png";
import etherlogo from "./etherlogo.png";
import homeicon from "./homeicon.png";
import lock from "./lock.png";
import question from "./question.png";
import arrowPrice from "./arrowdown1.png";
import wallet from "./wallet.png";
import arrowLeft from "./leftarrow.png";
import tick from "./tick.png";
import loading from "./loading.gif";

export default {
  uniswap,
  search,
  ether,
  arrow,
  arrowup,
  close,
  etherlogo,
  homeicon,
  lock,
  question,
  arrowPrice,
  wallet,
  arrowLeft,
  tick,
  loading,
};